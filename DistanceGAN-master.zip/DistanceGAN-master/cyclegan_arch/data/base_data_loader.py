
class BaseDataLoader(object):
    def __init__(self):
        pass
    
    def initialize(self, opt):
        self.opt = opt
        pass

    def load_data(self):
        return None

        
        
